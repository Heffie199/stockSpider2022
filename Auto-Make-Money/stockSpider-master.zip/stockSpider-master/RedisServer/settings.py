"""
# -*- coding: utf-8 -*-

"""
# 你的 redis 数据库配置
RedisHost = "127.0.0.1"
RedisPort = "6379"
RedisPassword = "123456"
RedisDB = "6"




