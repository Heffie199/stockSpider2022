"""
# -*- coding: utf-8 -*-
"""
# redis 数据库配置
RedisHost = "127.0.0.1"
RedisPort = "6379"
RedisPassword = "123456"
RedisDB = "6"

# mysql 数据库配置
MysqlHost = "127.0.0.1"
MysqlPort = 3306
MysqlUser = "root"
MysqlPassword = "123456"
MysqlDB = "Stock"




